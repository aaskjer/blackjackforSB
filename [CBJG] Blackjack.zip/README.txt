Installation:

In Streamer.bot:
- Import CBJG.sb
- Adjust settings if needed

(Optional) For the overlay in OBS:
- Drop the 'cards' folder into the root folder of SB
- install https://obsproject.com/forum/resources/source-copy.1261/
- In OBS: Tools > Source Copy > Load scene > blackjack-OBS-import.json
- Check if the images are still intakt


